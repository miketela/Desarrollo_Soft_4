
using System;

class Program {
    static void Main(string[] args) {
        int[] numeros = {1, 2, 3, 4, 5};

        Console.WriteLine("Los números en el arreglo son:");
        foreach (int numero in numeros) {
            Console.WriteLine(numero);
        }
    }
}
